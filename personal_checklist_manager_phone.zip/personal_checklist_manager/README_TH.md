# Personal Checklist Manager — Phone-First Edition

แอป Checklist ส่วนตัวสำหรับ iPhone และ Windows ใช้ Supabase Cloud Database และ GitHub Pages

## เริ่มต้นบน iPhone
อ่านไฟล์ **MOBILE_SETUP_TH.md** เป็นคู่มือหลักสำหรับติดตั้งทั้งหมดจาก iPhone โดยไม่ต้องใช้คอมพิวเตอร์

## ไฟล์ในโปรเจกต์
- `index.html` — โครงสร้างแอป
- `styles.css` — Responsive Dashboard UI
- `app.js` — ระบบจัดการ Checklist และ Cloud Sync
- `supabase.sql` — สร้าง Database, Row Level Security และ Realtime
- `manifest.webmanifest` — การติดตั้งแบบ PWA
- `icon.svg` — ไอคอน
- `MOBILE_SETUP_TH.md` — คู่มือติดตั้งจาก iPhone

## ฟีเจอร์
- Dashboard ภาพรวมงาน
- 4 Checklist เริ่มต้น: Weekly Review, Study, Goals & Projects, Monthly Review
- เพิ่ม แก้ไข ลบ และ Archive งาน
- Subtasks หนึ่งระดับ
- Priority, Due date, Notes
- Repeat รายสัปดาห์/รายเดือน
- Search และ Filters
- Email/Password authentication
- Cloud Database แยกข้อมูลตามบัญชีผู้ใช้
- Realtime update ระหว่างอุปกรณ์

## ความปลอดภัย
ใช้เฉพาะ Supabase public anon/publishable key ในหน้าเว็บ ห้ามใส่ `service_role` key หรือ Database Password ในโค้ดหรือ GitHub

## ข้อจำกัด
ต้องออนไลน์เพื่อใช้งาน Cloud; ยังไม่มี Offline Sync และ Push Notifications; Supabase และ GitHub Free Tier มีโควตาและข้อกำหนดที่อาจเปลี่ยนแปลง
