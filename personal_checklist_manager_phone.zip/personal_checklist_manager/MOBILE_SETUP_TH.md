# คู่มือติดตั้ง Personal Checklist Manager ด้วย iPhone เท่านั้น

คู่มือนี้ออกแบบสำหรับทำทุกขั้นตอนบน iPhone โดยไม่ต้องใช้ Windows หรือ Mac

## สิ่งที่ต้องมี
- iPhone และ Safari
- บัญชี GitHub
- บัญชี Supabase
- อินเทอร์เน็ต
- แอป Files (มีติดตั้งมากับ iPhone)

## ภาพรวม
1. ดาวน์โหลด ZIP จากแชต
2. แตก ZIP ในแอป Files
3. สร้าง GitHub Repository ผ่าน Safari
4. อัปโหลดไฟล์ที่แตกแล้วเข้า Repository
5. สร้างฐานข้อมูลใน Supabase
6. เปิด GitHub Pages
7. เชื่อมต่อ Supabase ในเว็บแอป
8. เพิ่มเว็บแอปลง Home Screen

## ขั้นตอนที่ 1: ดาวน์โหลดและแตกไฟล์
1. แตะลิงก์ ZIP ในแชต แล้วดาวน์โหลด
2. เปิดแอป Files → Browse → Downloads
3. แตะไฟล์ ZIP หนึ่งครั้งเพื่อแตกไฟล์
4. เปิดโฟลเดอร์ `personal_checklist_manager`
5. ตรวจสอบว่ามี `index.html`, `styles.css`, `app.js`, `supabase.sql` และไฟล์ประกอบ

**สำคัญ:** อย่าอัปโหลด ZIP เข้า GitHub โดยตรง เพราะ GitHub Pages ไม่แตก ZIP ให้ ต้องอัปโหลดไฟล์ที่แตกออกมาแล้ว

## ขั้นตอนที่ 2: สร้าง GitHub Repository
1. เปิด Safari ไปที่ https://github.com/
2. สมัครหรือเข้าสู่ระบบ
3. เปิดเมนู `+` แล้วเลือก **New repository**
4. ตั้งชื่อ `personal-checklist-manager`
5. เลือก **Public** เพื่อใช้ GitHub Pages ฟรีในแนวทางนี้
6. กด **Create repository**

## ขั้นตอนที่ 3: อัปโหลดไฟล์จาก iPhone
1. ใน Repository แตะ **Add file** → **Upload files**
2. แตะ **choose your files**
3. ในตัวเลือก Files ไปยังโฟลเดอร์ที่แตก ZIP ไว้
4. เลือกไฟล์ทั้งหมดภายในโฟลเดอร์โปรเจกต์ ไม่ใช่เลือก ZIP
5. รอให้อัปโหลดเสร็จ
6. เลื่อนลงไปที่ **Commit changes** แล้วกด

ถ้าเมนูแสดงผลไม่ครบ:
- แตะ `aA` ที่แถบที่อยู่ Safari
- เลือก **Request Desktop Website**
- หมุน iPhone เป็นแนวนอน

หากเลือกหลายไฟล์พร้อมกันยาก ให้อัปโหลดทีละไฟล์ได้ แต่ต้องให้ทุกไฟล์อยู่ระดับบนสุดของ Repository และ `index.html` ต้องไม่อยู่ในโฟลเดอร์ย่อย

## ขั้นตอนที่ 4: สร้าง Supabase Project
1. เปิด https://supabase.com/ ใน Safari
2. สมัครหรือเข้าสู่ระบบ
3. เลือก **New project**
4. ตั้งชื่อ เช่น `personal-checklist-manager`
5. ตั้ง Database Password ที่คาดเดายากและเก็บไว้เป็นส่วนตัว
6. เลือก Region ที่เหมาะสมและใกล้ประเทศไทย หากมี
7. สร้าง Project แล้วรอจนพร้อม

## ขั้นตอนที่ 5: สร้างฐานข้อมูล
1. ใน Supabase เปิด **SQL Editor**
2. เลือก **New query**
3. กลับไปแอป Files เปิด `supabase.sql`
4. เลือกข้อความทั้งหมดแล้ว Copy
5. กลับไป Safari วาง SQL ใน SQL Editor
6. กด **Run** และตรวจสอบว่าไม่มี Error

เคล็ดลับ: ถ้าเลือกข้อความยาก ให้เปิดไฟล์ใน Files แล้วแตะค้างในข้อความเพื่อเรียกเมนู Select All / Copy หรือใช้ Safari แบบ Request Desktop Website และหมุนเครื่องแนวนอน

## ขั้นตอนที่ 6: เปิด GitHub Pages
1. กลับไป GitHub Repository
2. เปิด **Settings** → **Pages**
3. ใน Build and deployment เลือก **Deploy from a branch**
4. Branch เลือก `main`
5. Folder เลือก `/ (root)`
6. กด **Save**
7. รอเผยแพร่ แล้วเปิด URL ที่หน้า Pages แสดง

URL โดยทั่วไปมีรูปแบบ `https://ชื่อผู้ใช้.github.io/personal-checklist-manager/`

## ขั้นตอนที่ 7: เชื่อมต่อ Supabase
1. ใน Supabase เปิด **Project Settings → API** หรือ **API Keys**
2. คัดลอก Project URL
3. คัดลอก public `anon` key หรือ `publishable` key
4. เปิด URL GitHub Pages ของแอป
5. วาง Project URL และ public key ในหน้า Connect
6. กด Connect แล้วสมัครด้วย Email และ Password
7. หากเปิด Email confirmation ให้ยืนยันอีเมลก่อน Login
8. เมื่อ Login สำเร็จ แอปจะสร้าง Checklist เริ่มต้น 4 หมวด

**ความปลอดภัย:** ใช้เฉพาะ public anon/publishable key ในหน้าเว็บ ห้ามใส่ `service_role` key หรือ Database Password ในแอปหรือ GitHub

## ขั้นตอนที่ 8: เพิ่มลง Home Screen
1. เปิดเว็บแอปด้วย Safari
2. แตะ Share
3. เลือก **Add to Home Screen**
4. ตั้งชื่อ `My Checklist`
5. แตะ Add แล้วเปิดจากไอคอนบนหน้าจอ

## ใช้งานร่วมกับ Windows ภายหลัง
เปิด URL เดิมผ่าน Chrome หรือ Edge แล้ว Login ด้วยบัญชีเดิม ข้อมูลชุดเดียวกันจะซิงก์ผ่าน Supabase Cloud

## ปัญหาที่พบบ่อย
- **GitHub Pages ยังไม่ขึ้น:** ตรวจสอบว่า `index.html` อยู่ระดับบนสุด และ Pages ตั้งค่า `main` + `/ (root)` แล้ว รอสักครู่ก่อน Refresh
- **Connect ไม่สำเร็จ:** ตรวจสอบ Project URL และ public key ว่าไม่มีช่องว่างเกิน
- **Login ไม่ได้หลังสมัคร:** ตรวจสอบอีเมลยืนยันและ Authentication settings
- **โหลดรายการไม่ได้:** ตรวจสอบว่า Run `supabase.sql` สำเร็จครบ
- **อัปโหลดไฟล์ไม่ได้:** ใช้ Request Desktop Website หรืออัปโหลดทีละไฟล์

## ข้อจำกัดของเวอร์ชันนี้
- ต้องออนไลน์เพื่ออ่านและบันทึก Cloud
- ไม่มี Offline Sync หรือ Push Notifications
- Repeat รองรับรายสัปดาห์และรายเดือน
- Subtasks รองรับหนึ่งระดับ
- GitHub Pages และ Supabase Free Tier มีโควตาและข้อกำหนดของผู้ให้บริการ
