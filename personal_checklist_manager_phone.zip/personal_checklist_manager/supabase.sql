-- Personal Checklist Manager database setup
-- Run this entire script in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.pcm_categories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 60),
  description text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.pcm_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  category_id uuid not null references public.pcm_categories(id) on delete cascade,
  parent_id uuid references public.pcm_tasks(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 160),
  notes text default '',
  priority text not null default 'medium' check (priority in ('low','medium','high')),
  due_date date,
  repeat_rule text not null default 'none' check (repeat_rule in ('none','weekly','monthly')),
  completed boolean not null default false,
  completed_at timestamptz,
  archived boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists pcm_categories_user_idx on public.pcm_categories(user_id);
create index if not exists pcm_tasks_user_idx on public.pcm_tasks(user_id);
create index if not exists pcm_tasks_category_idx on public.pcm_tasks(category_id);
create index if not exists pcm_tasks_due_idx on public.pcm_tasks(due_date);

alter table public.pcm_categories enable row level security;
alter table public.pcm_tasks enable row level security;

drop policy if exists "Users manage own categories" on public.pcm_categories;
create policy "Users manage own categories" on public.pcm_categories
for all to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users manage own tasks" on public.pcm_tasks;
create policy "Users manage own tasks" on public.pcm_tasks
for all to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- Enable Realtime for cross-device updates.
do $$ begin
  alter publication supabase_realtime add table public.pcm_categories;
exception when duplicate_object then null; when undefined_object then null;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.pcm_tasks;
exception when duplicate_object then null; when undefined_object then null;
end $$;

-- Validate that a task can only reference a category and parent task
-- owned by the same signed-in user. This prevents cross-account references.
create or replace function public.pcm_validate_task_ownership()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.pcm_categories c
    where c.id = new.category_id and c.user_id = new.user_id
  ) then
    raise exception 'Category must belong to the same user';
  end if;
  if new.parent_id is not null and not exists (
    select 1 from public.pcm_tasks p
    where p.id = new.parent_id
      and p.user_id = new.user_id
      and p.category_id = new.category_id
  ) then
    raise exception 'Parent task must belong to the same user and checklist';
  end if;
  return new;
end;
$$;

drop trigger if exists pcm_task_ownership_check on public.pcm_tasks;
create trigger pcm_task_ownership_check
before insert or update on public.pcm_tasks
for each row execute function public.pcm_validate_task_ownership();
