/* Personal Checklist Manager — client-side Supabase app */
const $ = (id) => document.getElementById(id);
const DEFAULT_CATEGORIES = [
  ["Weekly Review","Review, reflect and plan your next week"],
  ["Study","Learning, assignments and academic progress"],
  ["Goals & Projects","Milestones, projects and next actions"],
  ["Monthly Review","Monthly evaluation and improvement"]
];
let supabaseClient, user, categories=[], tasks=[], currentView="dashboard", currentCategory=null, authMode="login", realtimeChannel=null;
const configKey="pcm_supabase_config";

function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
function dateLabel(){return new Intl.DateTimeFormat("th-TH",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).format(new Date())}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function show(id){$(id).classList.remove("hidden")}
function hide(id){$(id).classList.add("hidden")}
function config(){try{return JSON.parse(localStorage.getItem(configKey)||"null")}catch{return null}}
function startConfig(){hide("auth-screen");hide("app");show("setup-screen");const c=config();if(c){$("project-url").value=c.url;$("anon-key").value=c.key}}
function connect(){
  const url=$("project-url").value.trim(),key=$("anon-key").value.trim();
  if(!url.startsWith("https://")||!key){toast("กรุณาตรวจสอบ Project URL และ public key");return}
  localStorage.setItem(configKey,JSON.stringify({url,key}));location.reload();
}
async function init(){
  $("today-label").textContent="YOUR WORKSPACE";$("date-chip").textContent=dateLabel();
  const c=config();if(!c){startConfig();return}
  try{supabaseClient=window.supabase.createClient(c.url,c.key)}catch(e){startConfig();return}
  const {data:{session}}=await supabaseClient.auth.getSession();
  if(session){user=session.user;await enterApp()}else{show("auth-screen")}
  supabaseClient.auth.onAuthStateChange(async(_event,session)=>{if(session&&!user){user=session.user;await enterApp()}else if(!session&&user){user=null;hide("app");show("auth-screen")}});
}
async function enterApp(){
  hide("auth-screen");hide("setup-screen");show("app");
  $("sync-label").textContent="Cloud connected";
  await loadData();renderAll();subscribeRealtime();
}
async function loadData(){
  const [c,t]=await Promise.all([
    supabaseClient.from("pcm_categories").select("*").order("created_at"),
    supabaseClient.from("pcm_tasks").select("*").order("created_at")
  ]);
  if(c.error||t.error){console.error(c.error,t.error);toast("โหลดข้อมูลไม่สำเร็จ ตรวจสอบ SQL setup และสิทธิ์ฐานข้อมูล");return}
  categories=c.data||[];tasks=t.data||[];
  if(!categories.length){for(const item of DEFAULT_CATEGORIES){const {data,error}=await supabaseClient.from("pcm_categories").insert({user_id:user.id,name:item[0],description:item[1]}).select().single();if(!error)categories.push(data)}}
}
function subscribeRealtime(){
  if(realtimeChannel)supabaseClient.removeChannel(realtimeChannel);
  realtimeChannel=supabaseClient.channel("pcm-live-"+user.id)
    .on("postgres_changes",{event:"*",schema:"public",table:"pcm_tasks",filter:`user_id=eq.${user.id}`},async()=>{await loadData();renderAll()})
    .on("postgres_changes",{event:"*",schema:"public",table:"pcm_categories",filter:`user_id=eq.${user.id}`},async()=>{await loadData();renderAll()})
    .subscribe();
}
function activeTasks(){return tasks.filter(t=>!t.archived)}
function taskChildren(id){return activeTasks().filter(t=>t.parent_id===id)}
function descendants(id){return tasks.filter(t=>t.parent_id===id)}
function categoryTasks(id){return activeTasks().filter(t=>t.category_id===id)}
function percent(list){if(!list.length)return 0;return Math.round(list.filter(t=>t.completed).length/list.length*100)}
function isOverdue(t){return !t.completed&&t.due_date&&t.due_date<new Date().toISOString().slice(0,10)}
function renderAll(){renderNav();renderDashboard();if(currentView!=="dashboard")renderList()}
function renderNav(){
  $("category-nav").innerHTML=categories.map(c=>`<div class="sidebar-category"><button class="nav-item" data-category="${c.id}"><span>☷</span>${escapeHtml(c.name)}</button><button class="delete-cat" data-delete-category="${c.id}" title="Delete checklist">×</button></div>`).join("");
  document.querySelectorAll("[data-category]").forEach(b=>b.onclick=()=>openCategory(b.dataset.category));
  document.querySelectorAll("[data-delete-category]").forEach(b=>b.onclick=()=>deleteCategory(b.dataset.deleteCategory));
}
function renderDashboard(){
  const list=activeTasks(),done=list.filter(t=>t.completed),over=list.filter(isOverdue);
  $("stat-total").textContent=list.length;$("stat-done").textContent=done.length;$("stat-open").textContent=list.length-done.length;$("stat-overdue").textContent=over.length;
  $("category-cards").innerHTML=categories.map(c=>{const a=categoryTasks(c.id),p=percent(a);return `<button class="category-card" data-open-category="${c.id}"><div class="category-top"><div class="category-icon">☷</div><span class="pill">${a.length} tasks</span></div><h3>${escapeHtml(c.name)}</h3><p>${escapeHtml(c.description||"Your checklist")}</p><div class="progress-track"><div class="progress-fill" style="width:${p}%"></div></div><div class="progress-meta"><span>${a.filter(t=>t.completed).length} completed</span><strong>${p}%</strong></div></button>`}).join("")||empty("No checklists yet","Create a checklist to get started.");
  document.querySelectorAll("[data-open-category]").forEach(b=>b.onclick=()=>openCategory(b.dataset.openCategory));
  const focus=list.filter(t=>!t.completed&&t.due_date).sort((a,b)=>a.due_date.localeCompare(b.due_date)).slice(0,6);
  $("focus-list").innerHTML=focus.length?focus.map(taskRow).join(""):empty("Nothing urgent","Tasks with due dates will appear here.");
  bindTaskRows();
}
function openCategory(id){currentCategory=id;currentView="list";hide("dashboard-view");show("list-view");$("page-title").textContent=categories.find(c=>c.id===id)?.name||"Checklist";renderList()}
function openAll(){currentCategory=null;currentView="all";hide("dashboard-view");show("list-view");$("page-title").textContent="All tasks";renderList()}
function renderList(){
  const q=($("search").value||"").toLowerCase(),status=$("status-filter").value,priority=$("priority-filter").value;
  let list=activeTasks().filter(t=>!t.parent_id);
  if(currentCategory)list=list.filter(t=>t.category_id===currentCategory);
  if(status==="open")list=list.filter(t=>!t.completed);if(status==="done")list=list.filter(t=>t.completed);if(status==="overdue")list=list.filter(isOverdue);
  if(status==="active")list=list.filter(t=>!t.completed);
  if(priority!=="all")list=list.filter(t=>t.priority===priority);
  if(q)list=list.filter(t=>`${t.title} ${t.notes||""}`.toLowerCase().includes(q));
  $("list-title").textContent=currentCategory?(categories.find(c=>c.id===currentCategory)?.name||"Checklist"):"All tasks";
  $("list-description").textContent=`${list.length} main tasks · subtasks included`;
  $("task-list").innerHTML=list.length?list.map(t=>taskRow(t,true)).join(""):empty("No tasks found","Add a task or change your filters.");
  bindTaskRows();
}
function taskRow(t,withChildren=false){
  const kids=withChildren?taskChildren(t.id):[];
  const due=t.due_date?new Date(t.due_date+"T00:00:00").toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}):"No deadline";
  return `<div class="task-row ${t.completed?"done":""}"><input class="task-check" type="checkbox" data-toggle="${t.id}" ${t.completed?"checked":""} aria-label="Complete task"><div class="task-content"><div class="task-name">${escapeHtml(t.title)}</div>${t.notes?`<div class="task-notes">${escapeHtml(t.notes)}</div>`:""}<div class="task-meta"><span class="pill ${t.priority}">${t.priority.toUpperCase()}</span><span class="pill ${isOverdue(t)?"overdue":""}">${due}</span>${t.repeat_rule!=="none"?`<span class="pill">↻ ${t.repeat_rule}</span>`:""}${withChildren&&kids.length?`<span class="pill">${kids.filter(k=>k.completed).length}/${kids.length} subtasks</span>`:""}</div>${kids.map(k=>`<div class="subtask-line"><input type="checkbox" data-toggle="${k.id}" ${k.completed?"checked":""}><span class="${k.completed?"done":""}">${escapeHtml(k.title)}</span></div>`).join("")}</div><div class="task-actions"><button class="mini-btn" data-edit="${t.id}" title="Edit">✎</button><button class="mini-btn" data-archive="${t.id}" title="Archive">▣</button><button class="mini-btn" data-delete="${t.id}" title="Delete">×</button></div></div>`;
}
function empty(title,desc){return `<div class="empty-state"><strong>${title}</strong>${desc}</div>`}
function bindTaskRows(){
  document.querySelectorAll("[data-toggle]").forEach(el=>el.onchange=()=>toggleTask(el.dataset.toggle,el.checked));
  document.querySelectorAll("[data-edit]").forEach(el=>el.onclick=()=>editTask(el.dataset.edit));
  document.querySelectorAll("[data-delete]").forEach(el=>el.onclick=()=>deleteTask(el.dataset.delete));
  document.querySelectorAll("[data-archive]").forEach(el=>el.onclick=()=>archiveTask(el.dataset.archive));
}
function fillCategorySelect(){
  $("task-category").innerHTML=categories.map(c=>`<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("");
  $("task-parent").innerHTML='<option value="">None — main task</option>'+activeTasks().filter(t=>!t.parent_id).map(t=>`<option value="${t.id}">${escapeHtml(t.title)}</option>`).join("");
}
function newTask(){
  $("task-form").reset();$("task-id").value="";$("task-dialog-title").textContent="New task";$("task-repeat").value="none";$("task-priority").value="medium";$("task-error").textContent="";
  fillCategorySelect();if(currentCategory)$("task-category").value=currentCategory;
  $("task-dialog").showModal();
}
function editTask(id){
  const t=tasks.find(x=>x.id===id);if(!t)return;
  fillCategorySelect();$("task-id").value=t.id;$("task-title").value=t.title;$("task-category").value=t.category_id;$("task-priority").value=t.priority;$("task-due").value=t.due_date||"";$("task-repeat").value=t.repeat_rule||"none";$("task-notes").value=t.notes||"";$("task-parent").value=t.parent_id||"";$("task-dialog-title").textContent="Edit task";$("task-error").textContent="";$("task-dialog").showModal();
}
async function saveTask(e){
  e.preventDefault();const id=$("task-id").value;
  const payload={user_id:user.id,category_id:$("task-category").value,title:$("task-title").value.trim(),priority:$("task-priority").value,due_date:$("task-due").value||null,repeat_rule:$("task-repeat").value,notes:$("task-notes").value.trim(),parent_id:$("task-parent").value||null};
  if(!payload.title)return;
  if(payload.parent_id===id){$("task-error").textContent="A task cannot be its own parent.";return}
  const res=id?await supabaseClient.from("pcm_tasks").update(payload).eq("id",id).select().single():await supabaseClient.from("pcm_tasks").insert(payload).select().single();
  if(res.error){$("task-error").textContent=res.error.message;return}
  $("task-dialog").close();await loadData();renderAll();toast(id?"Task updated":"Task created");
}
async function toggleTask(id,checked){
  const t=tasks.find(x=>x.id===id);if(!t)return;
  let update={completed:checked,completed_at:checked?new Date().toISOString():null};
  if(checked&&t.repeat_rule!=="none"&&t.due_date){const d=new Date(t.due_date+"T12:00:00");if(t.repeat_rule==="weekly")d.setDate(d.getDate()+7);if(t.repeat_rule==="monthly")d.setMonth(d.getMonth()+1);update={completed:false,completed_at:null,due_date:d.toISOString().slice(0,10)}}
  const {error}=await supabaseClient.from("pcm_tasks").update(update).eq("id",id);if(error)toast(error.message);else{await loadData();renderAll()}
}
async function deleteTask(id){if(!confirm("Delete this task?"))return;const {error}=await supabaseClient.from("pcm_tasks").delete().eq("id",id);if(error)toast(error.message);else{await loadData();renderAll();toast("Task deleted")}}
async function archiveTask(id){const {error}=await supabaseClient.from("pcm_tasks").update({archived:true}).eq("id",id);if(error)toast(error.message);else{await loadData();renderAll();toast("Task archived")}}
async function addCategory(e){
  e.preventDefault();const name=$("category-name").value.trim();if(!name)return;
  const {data,error}=await supabaseClient.from("pcm_categories").insert({user_id:user.id,name,description:$("category-description").value.trim()}).select().single();
  if(error){$("category-error").textContent=error.message;return}
  categories.push(data);$("category-dialog").close();$("category-form").reset();renderAll();toast("Checklist created");
}
async function deleteCategory(id){
  const c=categories.find(x=>x.id===id);if(!c||!confirm(`Delete "${c.name}" and its tasks?`))return;
  const {error}=await supabaseClient.from("pcm_categories").delete().eq("id",id);if(error){toast(error.message);return}
  await loadData();currentCategory=null;currentView="dashboard";show("dashboard-view");hide("list-view");$("page-title").textContent="Dashboard";renderAll();toast("Checklist deleted");
}
function navigate(view){if(view==="dashboard"){currentView="dashboard";show("dashboard-view");hide("list-view");$("page-title").textContent="Dashboard"}else openAll();document.querySelectorAll(".nav-item[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view))}
async function signOut(){await supabaseClient.auth.signOut();user=null;hide("app");show("auth-screen")}
function setupEvents(){
  $("save-config").onclick=connect;$("change-config").onclick=()=>{localStorage.removeItem(configKey);startConfig()};
  $("toggle-auth").onclick=()=>{authMode=authMode==="login"?"signup":"login";$("auth-title").textContent=authMode==="login"?"Welcome back":"Create account";$("auth-submit").textContent=authMode==="login"?"Sign in":"Sign up";$("toggle-auth").textContent=authMode==="login"?"ยังไม่มีบัญชี? สมัครสมาชิก":"มีบัญชีแล้ว? เข้าสู่ระบบ"};
  $("auth-form").onsubmit=async e=>{e.preventDefault();$("auth-message").textContent="Please wait...";const email=$("email").value.trim(),password=$("password").value;const r=authMode==="login"?await supabaseClient.auth.signInWithPassword({email,password}):await supabaseClient.auth.signUp({email,password});$("auth-message").textContent=r.error?r.error.message:(authMode==="signup"?"สมัครแล้ว หากเปิด Email confirmation ให้ตรวจสอบอีเมลเพื่อยืนยันบัญชี":"Signing in...")};
  $("sign-out").onclick=signOut;$("refresh").onclick=async()=>{await loadData();renderAll();toast("Synced")};
  $("top-add").onclick=newTask;$("list-add").onclick=newTask;$("add-category").onclick=$("dashboard-add-category").onclick=()=>$("category-dialog").showModal();
  $("task-form").onsubmit=saveTask;$("category-form").onsubmit=addCategory;
  document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>$(b.dataset.close).close());
  document.querySelectorAll(".nav-item[data-view]").forEach(b=>b.onclick=()=>navigate(b.dataset.view));
  document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>navigate(b.dataset.go));
  ["search","status-filter","priority-filter"].forEach(id=>$(id).addEventListener(id==="search"?"input":"change",renderList));
}
setupEvents();init();
